import { useState, useRef } from 'react';

// ─── Types ────────────────────────────────────────────────────────────────────
type Page = 'home'|'despre'|'servicii'|'portofoliu'|'preturi'|'colaboram'|'colaboram-custom'|'contact';

// ─── Footer ──────────────────────────────────────────────────────────────────
function PageFooter() {
  return (
    <footer className="page-footer">
      <span className="footer-copy">© 2026 USL MEDIA — Toate drepturile rezervate.</span>
      <div className="footer-center">
        <a
          href="https://www.instagram.com/usl.media?utm_source=ig_web_button_share_sheet&igsh=ZDNlZDc0MzIxNw=="
          target="_blank"
          rel="noreferrer"
          className="footer-ig"
        >
          <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <rect x="2" y="2" width="20" height="20" rx="5"/>
            <circle cx="12" cy="12" r="4"/>
            <circle cx="17.5" cy="6.5" r="1" fill="currentColor" stroke="none"/>
          </svg>
          @usl.media
        </a>
        <span className="footer-contact">uslmedia.contact@gmail.com</span>
      </div>
    </footer>
  );
}

// ─── Back button ─────────────────────────────────────────────────────────────
function BackBtn({ onClick }: { onClick: () => void }) {
  return (
    <button className="back-btn" onClick={onClick}>
      <svg viewBox="0 0 16 16"><polyline points="10,3 5,8 10,13"/></svg>
      Înapoi
    </button>
  );
}

// ─── Pages ───────────────────────────────────────────────────────────────────
function HomePage({ nav }: { nav: (p: Page) => void }) {
  return (
    <div className="page-inner" id="page-home">
      <div className="home-hero">
        <div className="home-eyebrow">
          <span className="eyebrow-dot"></span>
          Content Creator · București
        </div>
        <h1 className="home-h1">
          UȘURELU<br/>
          <span className="line2">ANDREI</span>
        </h1>
        <p className="home-sub">
          Cu mine totul este mai ușor, chiar și <strong>marketingul</strong> tău! Filmez și editez conținut video scurt care transformă afaceri în branduri vizibile. Lucrez cu businessuri în care văd potențial real — pentru că rezultatele contează cel mai mult.
        </p>
        <div className="home-btns">
          <button className="btn-primary" onClick={() => nav('portofoliu')}>Vezi portofoliu</button>
          <button className="btn-primary" onClick={() => nav('preturi')}>Pachete & Prețuri</button>
        </div>
        <div className="float-badge">
          <div className="float-badge-title">Ce ofer</div>
          <div className="equip-item"><span className="equip-dot"></span>Filmare profesionistă</div>
          <div className="equip-item"><span className="equip-dot"></span>Editare completă</div>
          <div className="equip-item"><span className="equip-dot"></span>Script inclus</div>
        </div>
      </div>
      <div className="home-stats">
        <div className="stat-item">
          <div className="stat-num">6<span>+</span></div>
          <div className="stat-lbl">Luni de experiență</div>
        </div>
        <div className="stat-item">
          <div className="stat-num">3<span>x</span></div>
          <div className="stat-lbl">Mai mult reach organic</div>
        </div>
        <div className="stat-item">
          <div className="stat-num">48<span>h</span></div>
          <div className="stat-lbl">Livrare rapidă</div>
        </div>
      </div>
      <PageFooter />
    </div>
  );
}

function DesprePage({ back }: { back: () => void }) {
  return (
    <div className="page-inner">
      <div className="despre-wrap">
        <BackBtn onClick={back} />
        <div className="page-label anim anim-1">Povestea mea</div>
        <h1 className="page-h1 anim anim-2">Despre <strong>mine</strong></h1>
        <div className="despre-photo-row anim anim-3">
          <div className="despre-photo-wrap">
            <img
              src="https://github.com/Andr31usl/uslmedia/raw/main/portofoliu%20site/poza%20eu.png"
              alt="Ușurelu Andrei — USL MEDIA"
              className="despre-photo"
            />
          </div>
          <div className="despre-text-col">
            <p>Mă numesc <strong>Ușurelu Andrei</strong> și sunt un content creator din București specializat în filmare și editare video scurtă pentru social media.</p>
            <p>Am început să filmez acum <strong>5 luni</strong> dintr-o pasiune sinceră pentru video și social media — am văzut că brandurile din jurul meu aveau nevoie de conținut vizual de calitate, dar nu aveau acces la el. Asta m-a motivat să iau lucrurile în mâini.</p>
            <p>Fiecare proiect vine cu <strong>script pregătit de mine</strong>, filmare cu gimbal stabilizat și echipament semiprofesional, editare completă și revizii — tot ce are nevoie un business ca să arate profesionist online.</p>
            <p>Lucrez doar cu businessuri în care văd potențial real. Nu accept orice client — prefer să construiesc relații pe termen lung cu afaceri care vor să crească cu adevărat pe Instagram și TikTok.</p>
            <div className="despre-aside-inline">
              <div className="aside-card">
                <div className="aside-card-label">Locație</div>
                <div className="aside-card-val">București, România</div>
              </div>
              <div className="aside-card">
                <div className="aside-card-label">Specializare</div>
                <div className="aside-card-val">Content Creation & Marketing</div>
              </div>
            </div>
          </div>
        </div>
        <div className="values-grid anim anim-4">
          <div className="value-card"><div className="value-icon">🎬</div><div className="value-title">Calitate Cinematică</div><div className="value-desc">Gimbal stabilizat pentru imagini fluide și profesioniste, gata de postat direct.</div></div>
          <div className="value-card"><div className="value-icon">⚡</div><div className="value-title">Livrare Rapidă</div><div className="value-desc">Script, filmare și editare livrate rapid, fără întârzieri sau birocrație.</div></div>
          <div className="value-card"><div className="value-icon">📈</div><div className="value-title">Focus pe Rezultate</div><div className="value-desc">Conținut creat strategic pentru reach organic maxim pe fiecare platformă.</div></div>
        </div>
      </div>
      <PageFooter />
    </div>
  );
}

function ServiciiPage({ back, nav }: { back: () => void; nav: (p: Page) => void }) {
  return (
    <div className="page-inner">
      <div className="servicii-wrap">
        <BackBtn onClick={back} />
        <div className="servicii-header">
          <div className="page-label anim anim-1">Ce livrez</div>
          <h1 className="page-h1 anim anim-2">Servicii <strong>premium</strong></h1>
          <p className="servicii-sub anim anim-3">Creez conținut video modern pentru businessuri care vor să arate profesionist, să crească organic și să transforme atenția în clienți reali.</p>
        </div>
        <div className="servicii-grid anim anim-4">
          {[
            { title: 'Filmare Video', desc: 'Filmare cinematică pentru branduri, restaurante, businessuri și content social media. Cadre fluide, lumină corectă și atenție la fiecare detaliu.', tags: ['Cinematic','Premium','4K Ready'], icon: (<svg viewBox="0 0 24 24"><rect x="3" y="6" width="15" height="12" rx="2"/><polygon points="18,10 22,8 22,16 18,14"/></svg>) },
            { title: 'Editare Video', desc: 'Editare rapidă și modernă cu subtitles, sound design și color grading. Totul optimizat pentru retenție și impact vizual.', tags: ['Fast Delivery','Storytelling','Retention'], icon: (<svg viewBox="0 0 24 24"><path d="M4 7h16"/><path d="M4 12h10"/><path d="M4 17h7"/></svg>) },
            { title: 'Reels & TikTok', desc: 'Conținut creat special pentru Instagram Reels și TikTok — hook puternic, editare rapidă și structură optimizată pentru viralizare.', tags: ['Instagram','TikTok','Organic Reach'], icon: (<svg viewBox="0 0 24 24"><rect x="6" y="2" width="12" height="20" rx="2"/><path d="M9 6h6"/></svg>) },
            { title: 'Social Media Growth', desc: 'Conținut strategic pentru branding modern, engagement și creștere organică. Nu doar videoclipuri frumoase — conținut care performează.', tags: ['Branding','Growth','Strategy'], icon: (<svg viewBox="0 0 24 24"><path d="M4 19V5"/><path d="M10 19V9"/><path d="M16 19V12"/><path d="M22 19V3"/></svg>) },
          ].map(s => (
            <div className="serv-card" key={s.title}>
              <div className="serv-icon">{s.icon}</div>
              <h3 className="serv-title">{s.title}</h3>
              <p className="serv-desc">{s.desc}</p>
              <div className="serv-tags">{s.tags.map(t => <span key={t}>{t}</span>)}</div>
            </div>
          ))}
        </div>
        <div className="servicii-header process-wrap">
          <div className="page-label">Proces simplu</div>
          <h2 className="page-h1" style={{fontSize:'clamp(2rem,4vw,3.2rem)',marginBottom:'1rem'}}>Cum <strong>lucrăm</strong></h2>
        </div>
        <div className="process-line anim anim-5">
          {[
            { title:'Filmare', desc:'Planificăm cadrele și filmăm conținut premium pentru businessul tău.', icon:(<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="3"/><path d="M20 12a8 8 0 1 1-8-8"/></svg>) },
            { title:'Editare', desc:'Editare cinematică și ritm modern pentru retenție și impact.', icon:(<svg viewBox="0 0 24 24"><path d="M4 7h16"/><path d="M4 12h10"/><path d="M4 17h7"/></svg>) },
            { title:'Livrare', desc:'Primești conținutul rapid, gata de postare pe toate platformele.', icon:(<svg viewBox="0 0 24 24"><path d="M22 2L11 13"/><path d="M22 2L15 22L11 13L2 9L22 2Z"/></svg>) },
            { title:'Optimizare', desc:'Ajustăm strategia și formatul pentru reach organic și rezultate mai bune.', icon:(<svg viewBox="0 0 24 24"><path d="M4 19h16"/><path d="M7 15l3-3 3 2 4-6"/></svg>) },
          ].map(s => (
            <div className="process-step" key={s.title}>
              <div className="process-step-icon">{s.icon}</div>
              <div className="process-title">{s.title}</div>
              <div className="process-desc">{s.desc}</div>
            </div>
          ))}
        </div>
        <div className="servicii-cta anim anim-6">
          <button className="btn-primary" onClick={() => nav('colaboram')}>Hai să lucrăm</button>
        </div>
      </div>
      <PageFooter />
    </div>
  );
}

function PortofoliuPage({ back }: { back: () => void }) {
  return (
    <div className="page-inner">
      <div className="porto-wrap">
        <BackBtn onClick={back} />
        <div className="porto-header">
          <div className="page-label anim anim-1">Munca vorbește</div>
          <h1 className="page-h1 anim anim-2" style={{fontSize:'clamp(2.5rem,5vw,4rem)'}}>Portofoliu</h1>
          <p className="anim anim-3" style={{color:'var(--muted)',fontWeight:300,fontSize:'0.95rem'}}>Proiecte reale, rezultate reale. Fiecare videoclip are un scop — să crești.</p>
        </div>
        <div className="video-grid anim anim-4">
          {[
            { src:'https://github.com/Andr31usl/uslmedia/raw/main/portofoliu%20site/1.mp4', title:'Cupa LazarxIoanid' },
            { src:'https://github.com/Andr31usl/uslmedia/raw/main/portofoliu%20site/2.mp4', title:'Dynamic Reel' },
            { src:'https://github.com/Andr31usl/uslmedia/raw/main/portofoliu%20site/3.mp4', title:'Dynamic Reel' },
          ].map((v,i) => (
            <div className="video-card" key={i}>
              <div className="video-wrap">
                <video controls preload="metadata" playsInline>
                  <source src={v.src} type="video/mp4"/>
                </video>
              </div>
              <div className="video-info">
                <p className="video-title">{v.title}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
      <PageFooter />
    </div>
  );
}

function PreturiPage({ back, nav }: { back: () => void; nav: (p: Page) => void }) {
  const checkIcon = (
    <span className="feat-icon">
      <svg viewBox="0 0 12 12"><polyline points="2,6 5,9 10,3"/></svg>
    </span>
  );
  return (
    <div className="page-inner">
      <div className="preturi-wrap">
        <BackBtn onClick={back} />
        <div className="preturi-header">
          <div className="page-label anim anim-1">Transparent & Simplu</div>
          <h1 className="page-h1 anim anim-2" style={{fontSize:'clamp(2.5rem,5vw,4rem)'}}>Prețuri</h1>
          <p className="anim anim-3" style={{color:'var(--muted)',fontWeight:300,fontSize:'0.95rem'}}>Alege pachetul potrivit pentru afacerea ta.</p>
        </div>
        <div className="pkg-grid anim anim-4">
          {/* Starter */}
          <div className="pkg">
            <div className="pkg-badge b-default">Starter</div>
            <div className="pkg-name">4 Video / Proiect</div>
            <div className="pkg-price">500 <span>lei</span></div>
            <p className="pkg-desc">Ideal dacă vrei să testezi colaborarea fără angajament pe termen lung.</p>
            <hr className="pkg-divider"/>
            <ul className="pkg-feats">
              {['4 video scurte (<60 sec)','Filmare & editare profesionistă','Script pregătit de mine','1 rundă de revizii per video','Format social media','Livrare rapidă'].map(f=><li key={f}>{checkIcon}{f}</li>)}
            </ul>
            <button className="pkg-btn outline" onClick={() => nav('colaboram')}>Alege Starter</button>
          </div>
          {/* Standard */}
          <div className="pkg featured">
            <div className="pkg-badge b-pop">⭐ Cel mai popular</div>
            <div className="pkg-name">8 Video / Lună</div>
            <div className="pkg-price">900 <span>lei / lună</span></div>
            <p className="pkg-desc">Conținut constant care construiește prezența online și aduce vizibilitate reală.</p>
            <hr className="pkg-divider"/>
            <ul className="pkg-feats">
              {['8 video scurte (<60 sec)','Filmare & editare profesionistă','Script pregătit de mine','1 rundă de revizii per video','Avantajos pe termen lung','Creșterea vizibilității online','Livrare rapidă'].map(f=><li key={f}>{checkIcon}{f}</li>)}
            </ul>
            <button className="pkg-btn solid" onClick={() => nav('colaboram')}>Alege Standard</button>
          </div>
          {/* Custom */}
          <div className="pkg custom">
            <div className="pkg-shimmer"></div>
            <div className="pkg-badge b-custom">✦ Personalizat</div>
            <div className="pkg-name">Colaborare Custom</div>
            <div className="pkg-price-tag">Preț personalizat</div>
            <p className="pkg-desc">Aceleași servicii, exact cum vrei tu. Totul se construiește în jurul brandului tău.</p>
            <hr className="pkg-divider"/>
            <ul className="pkg-feats">
              {['Video scurte — număr la alegere','Filmare & editare profesionistă','Script (opțional)','Runde de revizii la alegere','Stil vizual unitar','Livrare rapidă'].map(f=><li key={f}>{checkIcon}{f}</li>)}
            </ul>
            <button className="pkg-btn-custom" onClick={() => nav('colaboram-custom')}>Colaborare custom →</button>
          </div>
        </div>
      </div>
      <PageFooter />
    </div>
  );
}

// ─── Colab Form ───────────────────────────────────────────────────────────────
function ColabPage({ back }: { back: () => void }) {
  const [pkg, setPkg] = useState('');
  const [sent, setSent] = useState(false);
  const [loading, setLoading] = useState(false);
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [project, setProject] = useState('');

  const [qVideo, setQVideo] = useState('5');
  const [qRevizii, setQRevizii] = useState('2');
  const [qScript, setQScript] = useState('Da');
  const [qFilmare, setQFilmare] = useState('Interior');
  const [qPlatforme, setQPlatforme] = useState<string[]>(['TikTok']);

  const togglePlatforma = (p: string) => {
    setQPlatforme(prev => prev.includes(p) ? prev.filter(x => x !== p) : [...prev, p]);
  };

  const submit = async () => {
    if (!name || !phone || !email || !pkg || !project) return;
    setLoading(true);
    const payload: Record<string, string> = { name, email, phone, pachet: pkg, proiect: project };
    if (pkg === 'Custom') {
      payload.video_luna = qVideo;
      payload.revizii = qRevizii;
      payload.script = qScript;
      payload.filmare = qFilmare;
      payload.platforme = qPlatforme.join(', ') || '—';
    }
    try {
      await fetch('https://formspree.io/f/xqejabpp', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
        body: JSON.stringify(payload),
      });
    } catch {}
    setLoading(false);
    setSent(true);
  };

  if (sent) return (
    <div className="page-inner">
      <div className="contact-wrap">
        <div className="success-wrap" style={{display:'block'}}>
          <div className="success-icon"><svg viewBox="0 0 24 24"><polyline points="20,6 9,17 4,12"/></svg></div>
          <h3>Mesaj trimis!</h3>
          <p>Te contactez în maxim 2h. Mulțumesc!</p>
        </div>
      </div>
      <PageFooter />
    </div>
  );

  return (
    <div className="page-inner">
      <div className="contact-wrap">
        <BackBtn onClick={back} />
        <div className="contact-header">
          <div className="page-label anim anim-1">Hai să colaborăm</div>
          <h1 className="page-h1 anim anim-2" style={{fontSize:'clamp(2.5rem,5vw,4rem)'}}>Transformă ideea ta în <strong>content viral</strong></h1>
          <p className="anim anim-3" style={{color:'var(--muted)',fontWeight:300,fontSize:'0.95rem'}}>Completează formularul și te contactez în maxim 2h.</p>
        </div>
        <div className="colab-form-wrap anim anim-4">
          <div className="colab-field-row">
            <div className="colab-field"><label>Nume</label><input type="text" placeholder="Ion Popescu" value={name} onChange={e=>setName(e.target.value)} required/></div>
            <div className="colab-field"><label>Telefon</label><input type="tel" placeholder="07xx xxx xxx" value={phone} onChange={e=>setPhone(e.target.value.replace(/[^0-9]/g,''))} required/></div>
          </div>
          <div className="colab-field"><label>Email</label><input type="email" placeholder="ion@afacere.ro" value={email} onChange={e=>setEmail(e.target.value)} required/></div>
          <div className="colab-field">
            <label>Pachet de interes</label>
            <select value={pkg} onChange={e=>setPkg(e.target.value)}>
              <option value="" disabled>— Selectează un pachet —</option>
              <option value="Starter">Starter — 4 Video / Lună</option>
              <option value="Standard">Standard — 8 Video / Lună</option>
              <option value="Custom">Custom — Personalizat</option>
            </select>
          </div>
          {pkg === 'Custom' && (
            <div className="cq-section">
              <div className="cq-title">Configurează colaborarea</div>
              <div className="cq-item">
                <span className="cq-label">Câte video-uri pe lună?</span>
                <div className="cq-pills">
                  {['1','3','5','10'].map(v=><button key={v} className={`cust-pill${qVideo===v?' active':''}`} onClick={()=>setQVideo(v)}>{v}</button>)}
                </div>
              </div>
              <div className="cq-item">
                <span className="cq-label">Runde de revizii per video</span>
                <div className="cq-pills">
                  {['1','2','3'].map(v=><button key={v} className={`cust-pill${qRevizii===v?' active':''}`} onClick={()=>setQRevizii(v)}>{v}</button>)}
                </div>
              </div>
              <div className="cq-item">
                <span className="cq-label">Script inclus</span>
                <div className="cq-pills">
                  {['Da','Nu'].map(v=><button key={v} className={`cust-pill${qScript===v?' active':''}`} onClick={()=>setQScript(v)}>{v}</button>)}
                </div>
              </div>
              <div className="cq-item">
                <span className="cq-label">Tip filmare</span>
                <div className="cq-pills">
                  {['Interior','Exterior','Ambele'].map(v=><button key={v} className={`cust-pill${qFilmare===v?' active':''}`} onClick={()=>setQFilmare(v)}>{v}</button>)}
                </div>
              </div>
              <div className="cq-item">
                <span className="cq-label">Platforme țintă <span style={{fontSize:'0.72rem',color:'var(--muted)'}}>(poți alege mai multe)</span></span>
                <div className="cq-pills">
                  {['TikTok','Instagram','YouTube Shorts'].map(v=><button key={v} className={`cust-pill${qPlatforme.includes(v)?' active':''}`} onClick={()=>togglePlatforma(v)}>{v}</button>)}
                </div>
              </div>
            </div>
          )}
          <div className="colab-field"><label>Ce ai în minte?</label><textarea placeholder="Descrie pe scurt proiectul sau afacerea ta…" value={project} onChange={e=>setProject(e.target.value)} required/></div>
          <button className="colab-btn" onClick={submit} disabled={loading}>{loading ? 'Se trimite...' : 'Trimite mesajul →'}</button>
          <p className="colab-gdpr">Prin trimitere ești de acord cu prelucrarea datelor în scop de răspuns la cerere.</p>
        </div>
      </div>
      <PageFooter />
    </div>
  );
}

function ColabCustomPage({ back }: { back: () => void }) {
  const [sent, setSent] = useState(false);
  const [loading, setLoading] = useState(false);
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [descriere, setDescriere] = useState('');
  const [qVideo, setQVideo] = useState('5');
  const [qRevizii, setQRevizii] = useState('2');
  const [qScript, setQScript] = useState('Da');
  const [qFilmare, setQFilmare] = useState('Interior');
  const [qPlatforme, setQPlatforme] = useState<string[]>(['TikTok']);

  const togglePlatforma = (p: string) => setQPlatforme(prev => prev.includes(p) ? prev.filter(x => x !== p) : [...prev, p]);

  const submit = async () => {
    if (!name || !phone || !email || !descriere) return;
    setLoading(true);
    try {
      await fetch('https://formspree.io/f/xqejabpp', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
        body: JSON.stringify({ name, email, phone, pachet: 'Colaborare Custom', video_luna: qVideo, revizii: qRevizii, script: qScript, filmare: qFilmare, platforme: qPlatforme.join(', ') || '—', descriere }),
      });
    } catch {}
    setLoading(false);
    setSent(true);
  };

  if (sent) return (
    <div className="page-inner">
      <div className="contact-wrap">
        <div className="success-wrap" style={{display:'block'}}>
          <div className="success-icon"><svg viewBox="0 0 24 24"><polyline points="20,6 9,17 4,12"/></svg></div>
          <h3>Cerere trimisă!</h3>
          <p>Te contactez în maxim 24h cu o ofertă personalizată. Mulțumesc!</p>
        </div>
      </div>
      <PageFooter />
    </div>
  );

  return (
    <div className="page-inner">
      <div className="contact-wrap">
        <BackBtn onClick={back} />
        <div className="contact-header">
          <div className="page-label anim anim-1">Colaborare Custom</div>
          <h1 className="page-h1 anim anim-2" style={{fontSize:'clamp(2.5rem,5vw,4rem)'}}>Spune-mi ce <strong>vrei tu</strong></h1>
          <p className="anim anim-3" style={{color:'var(--muted)',fontWeight:300,fontSize:'0.95rem'}}>Completează chestionarul și descrie-mi viziunea. Te contactez în maxim 4h cu o ofertă personalizată.</p>
        </div>
        <div className="colab-form-wrap anim anim-4">
          <div className="colab-field-row">
            <div className="colab-field"><label>Nume</label><input type="text" placeholder="Ion Popescu" value={name} onChange={e=>setName(e.target.value)} required/></div>
            <div className="colab-field"><label>Telefon</label><input type="tel" placeholder="07xx xxx xxx" value={phone} onChange={e=>setPhone(e.target.value.replace(/[^0-9]/g,''))} required/></div>
          </div>
          <div className="colab-field"><label>Email</label><input type="email" placeholder="ion@afacere.ro" value={email} onChange={e=>setEmail(e.target.value)} required/></div>
          <div className="cq-section">
            <div className="cq-title">Configurează colaborarea</div>
            <div className="cq-item"><span className="cq-label">Câte video-uri pe lună?</span><div className="cq-pills">{['1','3','5','10'].map(v=><button key={v} className={`cust-pill${qVideo===v?' active':''}`} onClick={()=>setQVideo(v)}>{v}</button>)}</div></div>
            <div className="cq-item"><span className="cq-label">Runde de revizii per video</span><div className="cq-pills">{['1','2','3'].map(v=><button key={v} className={`cust-pill${qRevizii===v?' active':''}`} onClick={()=>setQRevizii(v)}>{v}</button>)}</div></div>
            <div className="cq-item"><span className="cq-label">Script inclus</span><div className="cq-pills">{['Da','Nu'].map(v=><button key={v} className={`cust-pill${qScript===v?' active':''}`} onClick={()=>setQScript(v)}>{v}</button>)}</div></div>
            <div className="cq-item"><span className="cq-label">Tip filmare</span><div className="cq-pills">{['Interior','Exterior','Ambele'].map(v=><button key={v} className={`cust-pill${qFilmare===v?' active':''}`} onClick={()=>setQFilmare(v)}>{v}</button>)}</div></div>
            <div className="cq-item"><span className="cq-label">Platforme țintă <span style={{fontSize:'0.72rem',color:'var(--muted)'}}>(poți alege mai multe)</span></span><div className="cq-pills">{['TikTok','Instagram','YouTube Shorts'].map(v=><button key={v} className={`cust-pill${qPlatforme.includes(v)?' active':''}`} onClick={()=>togglePlatforma(v)}>{v}</button>)}</div></div>
          </div>
          <div className="colab-field"><label>Spune-mi mai multe despre ce vrei</label><textarea placeholder="Descrie afacerea ta, tipul de content dorit, stilul vizual preferat, publicul țintă…" style={{minHeight:'160px'}} value={descriere} onChange={e=>setDescriere(e.target.value)} required/></div>
          <button className="colab-btn" onClick={submit} disabled={loading}>{loading ? 'Se trimite...' : 'Trimite cererea →'}</button>
          <p className="colab-gdpr">Prin trimitere ești de acord cu prelucrarea datelor în scop de răspuns la cerere.</p>
        </div>
      </div>
      <PageFooter />
    </div>
  );
}

function ContactPage({ back }: { back: () => void }) {
  const [sent, setSent] = useState(false);
  const [loading, setLoading] = useState(false);
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [mesaj, setMesaj] = useState('');

  const submit = async () => {
    if (!name || !email || !mesaj) return;
    setLoading(true);
    try {
      await fetch('https://formspree.io/f/xqejabpp', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
        body: JSON.stringify({ name, email, mesaj }),
      });
    } catch {}
    setLoading(false);
    setSent(true);
  };

  return (
    <div className="page-inner">
      <div className="contact-wrap">
        <BackBtn onClick={back} />
        <div className="contact-header">
          <div className="page-label anim anim-1">Contact</div>
          <h1 className="page-h1 anim anim-2" style={{fontSize:'clamp(2.5rem,5vw,4rem)'}}>Transformă ideea ta în <strong>content viral</strong></h1>
          <p className="anim anim-3" style={{color:'var(--muted)',fontWeight:300,fontSize:'0.95rem'}}>Spune-mi ce ai în minte și hai să construim ceva care atrage atenție.</p>
        </div>
        {sent ? (
          <div className="success-wrap" style={{display:'block'}}>
            <div className="success-icon"><svg viewBox="0 0 24 24"><polyline points="20,6 9,17 4,12"/></svg></div>
            <h3>Mesaj trimis!</h3>
            <p>Te contactez în maxim 2h. Mulțumesc!</p>
          </div>
        ) : (
          <div className="contact-new-split anim anim-4">
            <div className="contact-cards-col">
              <div className="contact-info-card">
                <div className="contact-info-icon" style={{background:'rgba(109,40,217,0.25)',borderColor:'rgba(139,92,246,0.3)'}}>
                  <svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="#a78bfa" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="2" y="4" width="20" height="16" rx="2"/><polyline points="2,4 12,13 22,4"/></svg>
                </div>
                <div className="contact-info-card-title">Contact</div>
                <div className="contact-info-card-text">uslmedia.contact@gmail.com</div>
              </div>
              <div className="contact-info-card">
                <div className="contact-info-icon" style={{background:'rgba(109,40,217,0.25)',borderColor:'rgba(139,92,246,0.3)'}}>
                  <svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="#a78bfa" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="2" y="2" width="20" height="20" rx="5"/><circle cx="12" cy="12" r="4"/><circle cx="17.5" cy="6.5" r="1" fill="#a78bfa" stroke="none"/></svg>
                </div>
                <div className="contact-info-card-title">Social Media</div>
                <div className="contact-info-card-text">@uslmedia pe Instagram & TikTok</div>
                <a href="https://www.instagram.com/usl.media?utm_source=ig_web_button_share_sheet&igsh=ZDNlZDc0MzIxNw==" target="_blank" rel="noreferrer" className="ig-link">
                  <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="2" y="2" width="20" height="20" rx="5"/><circle cx="12" cy="12" r="4"/><circle cx="17.5" cy="6.5" r="1" fill="currentColor" stroke="none"/></svg>
                  Urmărește pe Instagram
                </a>
              </div>
            </div>
            <div className="contact-form-card">
              <div className="cnf-field-row">
                <div className="cnf-field"><label>NUME</label><input type="text" placeholder="Numele tău" value={name} onChange={e=>setName(e.target.value)} required/></div>
                <div className="cnf-field"><label>EMAIL</label><input type="email" placeholder="email@exemplu.ro" value={email} onChange={e=>setEmail(e.target.value)} required/></div>
              </div>
              <div className="cnf-field"><label>MESAJ</label><textarea placeholder="Spune-mi despre ideea ta…" value={mesaj} onChange={e=>setMesaj(e.target.value)} required/></div>
              <button className="cnf-btn" onClick={submit} disabled={loading}>{loading ? 'Se trimite...' : 'Trimite mesajul ✈'}</button>
              <p className="cnf-gdpr">Prin trimitere ești de acord cu prelucrarea datelor în scop de răspuns la cerere.</p>
            </div>
          </div>
        )}
      </div>
      <PageFooter />
    </div>
  );
}

// ─── App Shell ────────────────────────────────────────────────────────────────

export default function App() {
  const [current, setCurrent] = useState<Page>('home');
  const [visible, setVisible] = useState<Page>('home');
  const [transitioning, setTransitioning] = useState(false);
  const [overlayVisible, setOverlayVisible] = useState(false);
  const [drawerOpen, setDrawerOpen] = useState(false);
  const history = useRef<Page[]>(['home']);

  const navigateTo = (page: Page) => {
    if (page === current || transitioning) return;
    setTransitioning(true);
    setOverlayVisible(true);
    // Stop videos
    document.querySelectorAll('video').forEach(v => { v.pause(); v.currentTime = 0; });
    history.current.push(page);

    setTimeout(() => {
      setCurrent(page);
      setVisible(page);
      window.scrollTo(0,0);
    }, 380);
    setTimeout(() => {
      setOverlayVisible(false);
      setTimeout(() => setTransitioning(false), 450);
    }, 650);
  };

  const goBack = () => {
    if (history.current.length > 1) {
      history.current.pop();
      const prev = history.current[history.current.length - 1] as Page;
      navigateTo(prev);
    }
  };

  const drawerNav = (page: Page) => {
    setDrawerOpen(false);
    setTimeout(() => navigateTo(page), 200);
  };

  const navItems: { id: Page; label: string }[] = [
    { id:'home', label:'Home' },
    { id:'despre', label:'Despre' },
    { id:'servicii', label:'Servicii' },
    { id:'portofoliu', label:'Portofoliu' },
    { id:'preturi', label:'Prețuri' },
  ];

  return (
    <>
      {/* Orbs */}
      <div className="orb orb-1"/>
      <div className="orb orb-2"/>

      {/* Transition overlay */}
      <div className="transition-overlay" style={{pointerEvents: overlayVisible ? 'all' : 'none'}}>
        <div className="t-panel" style={{transform: overlayVisible ? 'scaleY(1)' : 'scaleY(0)', transition:'transform 0.45s cubic-bezier(0.76,0,0.24,1)', transformOrigin: overlayVisible ? 'bottom' : 'top'}}/>
        <div className="t-logo" style={{opacity: overlayVisible ? 1 : 0, transition:'opacity 0.2s'}}>USL <span>MEDIA</span></div>
      </div>

      {/* Nav */}
      <nav>
        <a className="logo" href="#" onClick={e=>{e.preventDefault();navigateTo('home');}}>
          <div className="logo-main">USL <span>MEDIA</span></div>
          <div className="subtext">DIGITAL GROWTH AGENCY</div>
        </a>
        <ul className="nav-links">
          {navItems.map(n=>(
            <li key={n.id}>
              <a href="#" className={current===n.id?'active':''} onClick={e=>{e.preventDefault();navigateTo(n.id);}}>{n.label}</a>
            </li>
          ))}
        </ul>
        <button className="nav-cta" onClick={()=>navigateTo('colaboram')}>Hai să colaborăm</button>
        <button className="nav-cta nav-contact-secondary" onClick={()=>navigateTo('contact')}>✉ Contact</button>
        <button className={`hamburger${drawerOpen?' open':''}`} onClick={()=>setDrawerOpen(o=>!o)} aria-label="Meniu">
          <span/><span/><span/>
        </button>
      </nav>

      {/* Mobile drawer */}
      <div className={`mobile-drawer${drawerOpen?' open':''}`} onClick={e=>{if(e.target===e.currentTarget)setDrawerOpen(false);}}>
        <div className="mobile-drawer-links">
          {navItems.map(n=>(
            <a key={n.id} href="#" className={current===n.id?'active':''} onClick={e=>{e.preventDefault();drawerNav(n.id);}}>{n.label}</a>
          ))}
        </div>
        <div className="mobile-drawer-btns">
          <button className="mob-btn-primary" onClick={()=>drawerNav('colaboram')}>Hai să colaborăm</button>
          <button className="mob-btn-secondary" onClick={()=>drawerNav('contact')}>✉ Contact</button>
        </div>
        <div className="mobile-drawer-contact">uslmedia.contact@gmail.com</div>
      </div>

      {/* Page wrapper */}
      <div className="page-wrapper">
        <div className={`page${visible==='home'?' active':''}`}>
          <HomePage nav={navigateTo}/>
        </div>
        <div className={`page${visible==='despre'?' active':''}`}>
          <DesprePage back={goBack}/>
        </div>
        <div className={`page${visible==='servicii'?' active':''}`}>
          <ServiciiPage back={goBack} nav={navigateTo}/>
        </div>
        <div className={`page${visible==='portofoliu'?' active':''}`}>
          <PortofoliuPage back={goBack}/>
        </div>
        <div className={`page${visible==='preturi'?' active':''}`}>
          <PreturiPage back={goBack} nav={navigateTo}/>
        </div>
        <div className={`page${visible==='colaboram'?' active':''}`}>
          <ColabPage back={goBack}/>
        </div>
        <div className={`page${visible==='colaboram-custom'?' active':''}`}>
          <ColabCustomPage back={goBack}/>
        </div>
        <div className={`page${visible==='contact'?' active':''}`}>
          <ContactPage back={goBack}/>
        </div>
      </div>
    </>
  );
}
